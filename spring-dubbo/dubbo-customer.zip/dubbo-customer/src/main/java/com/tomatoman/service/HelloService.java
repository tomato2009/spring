package com.tomatoman.service;

public interface HelloService {

    String sayHello(String name);

}