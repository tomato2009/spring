1，测试redis的6种数据类型操作
2，redis的spring配置：com.tomatoman.redis.config.RedisConfig
3，测试：Junit测试